Introduction:
  SMS Plus is a freeware, open-source, portable emulator for the Sega Master System and Game Gear consoles. 

Changelog:
  v140909: Sound is now fully working greats to tmbinc 
           Back to menu with select key
  

Contact:
  http://ced2911.wata.fr | cedric2911@free.fr

Thanks:
  Tmbinc
  Charles MacDonald