/*
    stream.c --
    Sound stream management.
*/
#include "shared.h"
