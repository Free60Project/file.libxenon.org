
#ifndef _OSD_H_
#define _OSD_H_

#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <stdarg.h>
#include <allegro.h>
#include <time.h>
#include <audio.h>
#include <conio.h>  /* sealintf.c - getch() */

#include "shared.h"
#include "main.h"
#include "sealintf.h"
#include "config.h"
#include "blur.h"
#include "blit.h"
#include "ui.h"
#include "video.h"
#include "input.h"

#endif /* _OSD_H_ */
