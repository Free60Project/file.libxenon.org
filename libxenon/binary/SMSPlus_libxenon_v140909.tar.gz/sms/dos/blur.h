
#ifndef _BLUR_H_
#define _BLUR_H_

/* From blur.s */
extern void blur(uint16 *src, int line_width, int num_lines, int line_modulo);

#endif /* _BLUR_H_ */
