
#ifndef _MAIN_H_
#define _MAIN_H_

#define MAX_INPUTS 8

extern uint8 debug_on;
extern uint8 log_error;

#endif /* _MAIN_H_ */
