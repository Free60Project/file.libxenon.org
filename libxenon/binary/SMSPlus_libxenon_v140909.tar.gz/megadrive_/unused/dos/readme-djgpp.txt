Compile with DJGPP.
You will also need to install Allegro and Seal libraries.
Zlib is required for zipped rom support.