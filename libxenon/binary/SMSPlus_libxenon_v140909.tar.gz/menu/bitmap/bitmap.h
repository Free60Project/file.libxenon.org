//les surfaces extern

extern unsigned char arial_0[];		//512x512
extern unsigned char background[]; 	//1280x720
extern unsigned char xenonFileData[]; 	// 64x64
extern unsigned char xenonFolderData[];	 //64x64
extern unsigned char xenonCursorData[];	//64x64
