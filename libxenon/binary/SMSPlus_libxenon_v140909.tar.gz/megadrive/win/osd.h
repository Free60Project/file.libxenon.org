
#ifndef _OSD_H_
#define _OSD_H_

#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <time.h>
#include <conio.h>

#include "SDL.h"
#include <stdlib.h>

#include "error.h"
#include "shared.h"
#include "main.h"

#endif /* _OSD_H_ */
