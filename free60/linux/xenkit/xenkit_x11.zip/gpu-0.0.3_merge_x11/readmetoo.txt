DISCLAIMER :
GPU Heatsink on 360 can slowly damage your console components.
Pushing GPU to its extreme limit through homebrew or mere testing
is not recommended unless you water cool your console.
You have been warned! (Doing a water cool mod is NOT that hard...)

Changes in this version "gpu-0.0.3_merge_x11" :
- Mouse & Keyboard events support through standard X11 library
- Various graphic functions for your casual display in window
- 2D clipping of the "resolve" function, in order to match window size

Important note : unfortunately, there is still screen flickering
Need to find a way to prevent OS from refreshing window content. Honestly, 
it's time to create a new KK patch so we can start homebrew another way.

Changes in this version "gpu-0.0.3_merge" :

- merge of gpu-0.0.3 and romextract-0.0.1 (no need to generate .bin files)
- 4 mspack files added (found in libmspack-0.0.20060920alpha.tar.gz, 
  from http://www.cabextract.org.uk/libmspack/)
- no more infinite loop in gpu.c (so you don't have to reboot gentoo)
  (loops for a number of frames, then quit. look for top constant in gpu.c)
- 3DSMax mesh extraction functions added (coming from pbKit Demo 04)
- 3DSMax 5 sample meshes "Polyship" and "Biplane" added to archive
  (define MESH1 for "Polyship" or MESH2 for "Biplane" at top of gpu.c)

Important note 1 :
At top of romextract.c, tmbinc had to add "#define _FILE_OFFSET_BITS 64"
in order to avoid crashes on Debian (his distro of Linux, running on HDD).
He explains it on his blog (http://x226.org).
Under Gentoo LiveCD Beta 2, it's the reverse. This constant MUST NOT be declared.
This "merge" version can compile immediately under Gentoo LiveCD Beta 2.
If you have Debian and it crashes, do the change at top of romextract.c.

Important note 2 :
Under 1080i, you will see graphics on the left part of screen (1024x768).
(current fix in gpu_resolve.c, at bottom, in order to avoid wrong resolve)
I'm working on enabling full screen under 1080i... Stay tuned.

Screen flickering will vanish when I will add a silly X11 empty window.
(That way desktop won't try to draw at same time and same place as the demo)

Will try to add lighting too, when I have free time (only weekends).

Have fun with the (double) wonderful gift from tmbinc! Thanks tmbinc!

openxdkman
