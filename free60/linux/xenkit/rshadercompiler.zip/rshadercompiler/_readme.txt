A wonderful tool, from Tser, allowing to compile 360 shaders
with XNA for Windows (no need to subscribe to creator's club).

Successfully tested with XNA 1.0.

How to :
Either read program.cs header or
Open project (.sln), and run it. It should compile 4 shaders.
These shaders are used in tmbinc's demo "gpu-0.0.3".
It can compile the supplied sample .fx too. See source.

Thanks a lot, Tser!