//3D Tutorial: http://www.expertrating.com/courseware/3DCourse/3D-Tutorial.asp
//.max=>.3DS : Select object, File->Export selected (in 3DSMax)
//Add new calls to parse_mesh with new objectnames in mesh.c
//or just gather all your objects in same .3DS file
//"/meshes" subdirectory must be copied in the binary directory
//(.max files are given just to allow texture changes)

#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <string.h>
#include <byteswap.h>
#include <math.h>
#include <signal.h>


typedef unsigned short u16;
typedef unsigned int u32;

#define READ16(p) ((((u16)(*((p)+1)))<<8)|(((u16)(*((p)+0)))<<0))
#define READ32(p) ((((u32)(*((p)+3)))<<24)|(((u32)(*((p)+2)))<<16)|(((u32)(*((p)+1)))<<8)|(((u32)(*((p)+0)))<<0))





//Retrievable ChunkIDs
#define MESH_VERTICES	0x4110
#define MESH_FACES	0x4120
#define MESH_MATERIAL	0x4130
#define MESH_MAPPING	0x4140
#define MESH_MAPNAME	0xA300



int verbose=0;

#define pb_print printf

//find address of a specific chunk for a specific object name (null=first object)
unsigned char *parse_mesh(unsigned char *p,u32 size,char *objectname,u16 chunk)
{
	u32	i;
	int	object_found=0;
	int	map_type=0;
	
	unsigned char *pEnd;
	
	u16	ChunkID;
	u32	ChunkLen;

	u16	Number;

	ChunkID=READ16(p);
	
	if (ChunkID!=0x4d4d)
	{
		if (verbose)
			pb_print("Not a 3DS file\n");

		return NULL;
	}
	
	ChunkLen=READ32(p+2);
	pEnd=p+ChunkLen-6;

	while (p<pEnd)
	{
		if ((object_found)&&(READ16(p)==chunk)) return p+6;
		
		ChunkID=READ16(p); p+=2;
		ChunkLen=READ32(p); p+=4;

		switch (ChunkID)
		{
			case 0x4d4d: break; //main chunk (nothing + sub chunks)

			case 0x0002: //3DS version

				if (verbose)
					pb_print("3DS-v%d\n",READ32(p));

				p+=4;
				break;

			case 0x3d3d: break; //3D editor chunk (nothing + sub chunks)

			case 0x3d3e: //mesh version

				if (verbose)
					pb_print("Mesh-v%d\n",READ32(p));

				p+=4;
				break;

			case 0x0100: //one unit
				if (verbose)
				{
					if (READ32(p)==0x3f800000)
						pb_print("Unit=1.0f\n");
					else
						pb_print("Unit=%x\n",READ32(p));
				}
				p+=4;
				break;

			case 0x4000: //object block (object name + sub chunks)
				if (verbose)
					pb_print("Object: '%s'\n",p);

				if (objectname==NULL) 
					object_found=1;
				else
				{
					if (strcmp(objectname,(char *)p)==0)
						object_found=1;
					else
						object_found=0;
				}
				p+=strlen((char *)p)+1;
				break;

			case 0x4100: break; //triangular mesh (nothing + sub chunks)

			case 0x4110: //vertices list (number + 3 floats per vertex + sub chunks)
				Number=READ16(p); p+=2;
				if (verbose)
					pb_print("Number of vertices: %d\n",Number);

				for (i=0; i<Number; i++)
				{
					p+=3*4;
				}
				break;

			case 0x4111: //vertices flags (number + 1 short per flag + sub chunks)
				Number=READ16(p); p+=2;
				//if (verbose)
				//	pb_print("Number of vertices flags: %d\n",Number);

				for (i=0; i<Number; i++)
				{
					p+=2;
				}
				break;

			case 0x4120: //faces list (number + 4 shorts per face + sub chunks)
				Number=READ16(p); p+=2;              
				if (verbose)
					pb_print("Number of polygons: %d\n",Number); 

				for (i=0; i<Number; i++)
				{
					p+=4*2;
				}
				break;

			case 0x4130: //faces material (name + number + faces material list)
				if (verbose)
					pb_print("Faces material : '%s'\n",p);

				p+=strlen((char *)p)+1;
				Number=READ16(p); p+=2;              
				if (verbose)
					pb_print("Number of faces material: %d\n",Number);

				for (i=0; i<Number; i++)
				{
					p+=2;
				}
				break;

			case 0x4140: //mapping points list (number + 2 floats per mapping point)
				Number=READ16(p); p+=2;              
				if (verbose)
					pb_print("Number of mapping points: %d\n",Number); 

				for (i=0; i<Number; i++)
				{
					p+=2*4;
				}
				break;

			case 0x4150: //smooth list (1 dword per mapping point)
				p+=ChunkLen-6;
				break;

			case 0x4160: //coordinates (6 floats)
				p+=ChunkLen-6;
				break;

			case 0x4165: //color in editor (1 byte)
				p+=ChunkLen-6;
				break;

			case 0x4600: //light (3 floats x,y,z + sub chunks)
				p+=3*4;
				break;

			case 0x4610: //spotlight (5 floats target(x,y,z) + hotspot + falloff + sub chunks)
				p+=5*4;
				break;

			case 0x4627: //spotlight raytrace bias (nothing + sub chunks)
				break;

			case 0x4630: //spotlight shadowed (nothing + sub chunks)
				break;

			case 0x4641: //spotlight shadow map (10 bytes + sub chunks)
				p+=10;
				break;
				
			case 0x4656: //spotlight roll (1 float)
				p+=4;
				break;

			case 0x4658: //spotlight raytrace bias (1 float)
				p+=4;
				break;

			case 0x4659: //light range start (1 float)
				p+=4;
				break;

			case 0x465a: //light range end (1 float)
				p+=4;
				break;

			case 0x465b: //light multiplier (1 float)
				p+=4;
				break;

			case 0x4700: //camera (8 floats Pos(x,y,z) Target(x,y,z) Bank(degree) Lens + sub chunks)
				p+=32;
				break;

			case 0x4720: //camera ? (2 dwords)
				p+=8;
				break;

			case 0xafff: break; //Material editor chunk (nothing + sub chunks)

			case 0xa000: //Material block (material name + sub chunks)
				if (verbose)
					pb_print("Material: '%s'\n",p);

				p+=strlen((char *)p)+1;
				break;

			case 0xa010: //ambient color (1 color sub chunk)
				break;

			case 0x0010: //color (3 floats)
				p+=3*4;
				break;
			case 0x0011: //color (3 bytes)
				p+=3;
				break;
			case 0x0012: //gamma corrected color (3 bytes)
				p+=3;
				break;
			case 0x0013: //gamma corrected color (3 float)
				p+=3*4;
				break;
			
			case 0xa020: //diffuse color (1 color sub chunk)
				break;

			case 0xa030: //specular color (1 color sub chunk)
				break;

			case 0xa040: //shininess percent (1 percent sub-chunk)
				break;

			case 0x0030: //percent (1 short)
				p+=2;
				break;
			case 0x0031: //percent (1 float)
				p+=4;
				break;

			case 0xa041: //Shininess strength percent (1 percent sub-chunk)
				break;

			case 0xa050: //transparency percent (1 percent sub-chunk)
				break;

			case 0xa052: //transparency fallout percent (1 percent sub-chunk)
				break;

			case 0xa053: //Reflection blur percent (1 percent sub-chunk)
				break;

			case 0xa084: //Selfilum (1 percent sub-chunk)
				break;
				
			case 0xa087: //Wire thickness (1 float)
				p+=4;
				break;

			case 0xa08a: //Falloff in (nothing)
				break;

			case 0xa100: //Render type (1 word)
				p+=2;
				break;

			case 0xa200: //Texture map 1 (nothing + sub chunks)
			case 0xa204: //Specular map filename (nothing + sub chunks)
			case 0xa210: //Opacity map filename (nothing + sub chunks)
			case 0xa220: //Reflection map filename (nothing + sub chunks)
			case 0xa230: //Bump map filename (nothing + sub chunks)
			case 0xa33a: //Texture map 2 (nothing + sub chunks)
			case 0xa33c: //Shininess map (nothing + sub chunks)
			case 0xa33d: //Selfilum map (nothing + sub chunks)
			case 0xa33e: //Mask for texture map 1 (nothing + sub chunks)
			case 0xa340: //Mask for texture map 2 (nothing + sub chunks)
			case 0xa342: //Mask for opacity map filename (nothing + sub chunks)
			case 0xa344: //Mask for bump map filename (nothing + sub chunks)
			case 0xa346: //Mask for shininess map (nothing + sub chunks)
			case 0xa348: //Mask for specular map filename (nothing + sub chunks)
			case 0xa34a: //Mask for selfilum map (nothing + sub chunks)
			case 0xa34c: //Mask for reflection map filename (nothing + sub chunks)
				map_type=ChunkID;
				break;
	
			case 0xa300: //filename (filename + sub chunks)
				if (verbose)
					pb_print("%04x-map filename: '%s'\n",map_type,p);

				p+=strlen((char *)p)+1;
				break;

			case 0xa351: //Mapping parameters (1 word, usually 0x0000)
				p+=2;
				break;

			case 0xa353: //Blur percent (1 float)
				p+=4;
				break;
				
			case 0xb000: //Key framer (nothing + sub chunks)
				break;

			case 0xb001: break; //Ambient light information block (nothing + sub chunks)
			case 0xb002: break; //Mesh information block (nothing + sub chunks)
			case 0xb003: break; //Camera information block (nothing + sub chunks)
			case 0xb004: break; //Camera target information block (nothing + sub chunks)
			case 0xb005: break; //Omni light information block (nothing + sub chunks)
			case 0xb006: break; //Spotlight target information block (nothing + sub chunks)
			case 0xb007: break; //Spotlight information block (nothing + sub chunks)

			case 0xb008: //Frames start and end (2 dwords)
				p+=2*4;
				break;

			case 0xb009: //? (1 dword)
				p+=4;
				break;

			case 0xb00a: //Scene ID (word + scene name + dword)
				p+=2;
				//if (verbose)
				//	pb_print("Scene name: '%s'\n",p);

				p+=strlen((char *)p)+1;
				p+=4;
				break;

			case 0xb010: //object name (+3 words 2 flags and 1 parent ptr)
				//if (verbose)
				//	pb_print("Key frame Object name: '%s'\n",p);

				p+=strlen((char *)p)+1;
				p+=3*2;
				break;

			case 0xb013: //pivot point (3 floats x,y,z)
				p+=3*4;
				break;

			case 0xb020: //track position (3 floats x,y,z + 5 floats ?)
				p+=8*4;
				break;

			case 0xb021: //track rotation (1 float angle + 3 floats axis + 5 floats ?)
				p+=9*4;
				break;

			case 0xb022: //track scale (3 floats x,y,z + 5 floats ?)
				p+=8*4;
				break;

			case 0xb023: //track field of view (1 float angle + 5 floats ?)
				p+=6*4;
				break;

			case 0xb024: //track roll (1 float angle + 5 floats ?)
				p+=6*4;
				break;

			case 0xb025: //track color (3 floats r,g,b + 5 floats ?)
				p+=8*4;
				break;
			
			case 0xb027: //track hotspot (1 float angle + 5 floats ?)
				p+=6*4;
				break;

			case 0xb028: //track falloff (1 float angle + 5 floats ?)
				p+=6*4;
				break;

			case 0xb030: //hierarchy position ID (1 word)
				p+=2;
				break;

			default:
				if (verbose)
					pb_print("[%x?,%d bytes]\n",ChunkID,ChunkLen);
				p+=ChunkLen-6;
				return NULL; //better stop exploring
				break;
		}
	}

	return NULL; //found nothing
}





