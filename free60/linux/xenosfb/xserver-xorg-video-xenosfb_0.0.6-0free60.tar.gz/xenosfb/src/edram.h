#ifndef __xenos_edram_h
#define __xenos_edram_h

#ifdef __cplusplus
extern "C" {
#endif

#include <xe.h>

void edram_init(struct XenosDevice *xe);

#ifdef __cplusplus
};
#endif

#endif 